from google import genai
from google.genai import types, errors

# from ignite.tools.ai.embedder import get_embedding
# from ignite.web.common import *
# from ignite.core.config import config
# from ignite.core.utils.current import current
# from mongoengine import Q
import faiss
import numpy as np
#client = genai.Client(api_key=config.gemini.api_key)
#client = genai.Client(api_key="AIzaSyBaaxpAPP_PYdMWxIsLEMLhc_b54kEfl7Q")
MODEL = "gemini-2.0-flash"

class AI:
    def __init__(self, api_key: str, prompt):
        self.client = genai.Client(api_key=api_key)
        self.user_prompt = f"{prompt}"
        self.input_token_limit = self.client.models.get(model=MODEL).input_token_limit
        self.output_token_limit = self.client.models.get(model=MODEL).output_token_limit

        self.ADDITIONAL_CONTEXT_RULES = []