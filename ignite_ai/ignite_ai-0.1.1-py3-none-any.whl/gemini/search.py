import json

from google import genai
from google.genai import types, errors

from typing import List
from typing_extensions import TypedDict
from pydantic_extensions.models import *
# from ignite.tools.ai.embedder import get_embedding
# from ignite.web.common import *
# from ignite.core.config import config
# from ignite.core.utils.current import current
# from mongoengine import Q
import faiss
import numpy as np
#client = genai.Client(api_key=config.gemini.api_key)
#client = genai.Client(api_key="AIzaSyBaaxpAPP_PYdMWxIsLEMLhc_b54kEfl7Q")
MODEL = "gemini-2.0-flash"

class SourcesSchema(TypedDict):
    source_ranking: int
    object_id: str
    object_type: str
    name: str
    # source: str
    confidence_score: float


class SearchResultsSchema(TypedDict):
    answer: str
    sources: List[SourcesSchema]
    ignored_sources: List[SourcesSchema]
    confidence_score: float


class Search:
    def __init__(self, api_key: str, prompt: SearchPrompt):
        self.client = genai.Client(api_key=api_key)


        # prompt_combined = " ".join(ADDITIONAL_CONTEXT_RULES)
        prompt_combined = " "
        self.user_prompt = prompt
        self.combined_prompt = f"{prompt_combined} {prompt}"
        self.ai_search = []
        self.input_token_limit = self.client.models.get(model=MODEL).input_token_limit
        self.output_token_limit = self.client.models.get(model=MODEL).output_token_limit


        self.search_chunks = []
        self.ADDITIONAL_CONTEXT_RULES = []

    def response(self):
        print("Searching...")

        # if not self.user_prompt:
        #     return

        # model = genai.GenerativeModel(MODEL)

        # prompt_combined = " ".join(ADDITIONAL_CONTEXT_RULES)
        # prompt_combined = f"{prompt_combined} {self.prompt}"
        json_converted_results = [self.combined_prompt]

        # response = model.generate_content(
        #     model=MODEL,
        #     contents=json_converted_results,
        #     generation_config=genai.GenerationConfig(
        #         response_mime_type="application/json", response_schema=SearchResultsSchema
        #     ),
        # )

        # ADDITIONAL_CONTEXT_RULES = [
        #     context.context_rule for context in m.IgniteAssistantContext.objects(type="ask_ignite", is_active=True)
        # ]
        #
        # self.ADDITIONAL_CONTEXT_RULES = ADDITIONAL_CONTEXT_RULES

        ADDITIONAL_CONTEXT_RULES = []

        if len(self.user_prompt.context) == 0:
            self.user_prompt.context.append("No additional context")


        best_result = None
        best_confidence = -1

        print(type(self.user_prompt.prompt))

        if type(self.user_prompt.prompt) is str:
            print("Is string")
            try:
                response = self.client.models.generate_content(
                    model=MODEL,
                    contents=self.user_prompt.prompt,
                    config=types.GenerateContentConfig(
                        system_instruction=self.user_prompt.context,
                        response_mime_type="application/json",
                        response_schema=SearchResultsSchema,
                    ),
                )

                result = json.loads(response.text)


                if result and result.get("confidence_score", 0) > best_confidence:
                    best_result = result
                    best_confidence = result["confidence_score"]

            except errors.APIError as e:

                print(e.code)  # 404

                print(e.message)

        elif type(self.user_prompt.prompt) is list:
            print("Is list")
            for search_chunk in self.user_prompt.prompt:

                try:
                    response = self.client.models.generate_content(
                        model=MODEL,
                        contents=search_chunk,
                        config=types.GenerateContentConfig(
                            system_instruction=self.user_prompt.context,
                            response_mime_type="application/json",
                            response_schema=SearchResultsSchema,
                        ),
                    )

                    result = json.loads(response.text)

                    if result and result.get("confidence_score", 0) > best_confidence:
                        best_result = result
                        best_confidence = result["confidence_score"]

                except errors.APIError as e:

                    print(e.code)  # 404

                    print(e.message)


        return best_result







