import re

from google import genai
from google.genai import types, errors

from gemini.ai import AI
# from ignite.tools.ai.embedder import get_embedding
# from ignite.web.common import *
# from ignite.core.config import config
# from ignite.core.utils.current import current
# from mongoengine import Q
import faiss
import numpy as np
#client = genai.Client(api_key=config.gemini.api_key)
#client = genai.Client(api_key="AIzaSyBaaxpAPP_PYdMWxIsLEMLhc_b54kEfl7Q")
MODEL = "gemini-2.0-flash"


class SpamDetector(AI):
    def __init__(self, api_key: str, prompt: str):
        #super().__init__(api_key, prompt)
        self.user_prompt = prompt

    def response(self):
        pass

    def count_hits(self, patterns, text):
        return sum(bool(re.search(p, text, re.IGNORECASE)) for p in patterns)

    def rule_score(self, text: str, cfg: dict) -> dict:
        """
        Pure rules. Returns a probability-like confidence in [0,1] for 'ham'.
        Heuristic: allowlist hits push up; denylist hits, many links/phones/emails/emojis push down.
        """

        _url_re = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
        _email_re = re.compile(r"\b[\w\.-]+@[\w\.-]+\.\w+\b")
        _phone_re = re.compile(r"\+?\d[\d\-\s()]{6,}\b")
        _emoji_re = re.compile(r"[\U0001F300-\U0001FAFF]")


        t = text.strip()
        if not t:
            return {"label": "spam", "confidence": 0.99, "signals": {"empty": True}}

        allow_hits = self.count_hits(cfg["allowlist_phrases"], t)
        deny_hits = self.count_hits(cfg["denylist_phrases"], t)
        urls = len(_url_re.findall(t))
        emails = len(_email_re.findall(t))
        phones = len(_phone_re.findall(t))
        emojis = len(_emoji_re.findall(t))
        length = len(t)

        # Base score from allow/deny
        score = 0.5 + 0.18 * allow_hits - 0.22 * deny_hits

        # Link/email/phone/emojis penalties (non-linear caps)
        score -= min(urls, 3) * 0.10
        score -= min(emails, 2) * 0.08
        score -= min(phones, 2) * 0.10
        score -= min(emojis // 4, 3) * 0.05

        # Very short or extremely long text: push to spam
        if length < 8:
            score -= 0.10
        if length > 800:
            score -= 0.10

        # Clamp to [0,1]
        p_ham = max(0.0, min(1.0, score))

        label = "ham" if p_ham >= cfg["thresholds"]["HAM_THRESHOLD"] else (
            "spam" if p_ham < cfg["thresholds"]["REVIEW_LOW"] else "review")

        return {
            "label": label,
            "confidence": p_ham if label != "spam" else (1 - p_ham),
            "signals": {
                "allow_hits": allow_hits, "deny_hits": deny_hits,
                "url_count": urls, "email_count": emails, "phone_count": phones,
                "emoji_count": emojis, "length": length
            }
        }
