from typing import Union, Optional
from pydantic import BaseModel, Field

class SearchPrompt(BaseModel):
    prompt: str | list
    context: list | None = []
    answer: str | None = None   # ← optional


class EmbedderModel(BaseModel):
    text: str | list
    embedded_text: list | None = None


# class SearchPrompt(BaseModel):
#     prompt: Union[str, list[str]]          # accepts "hello" or ["hello", "world"]
#     context: list[str] = Field(default_factory=list)
#     answer: Optional[str] = None


class AnswerSearchPrompt(BaseModel):
    answer: str