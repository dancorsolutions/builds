import json
from typing import Optional

import requests
#todo to move later
#from google import genai

class Client:
    def __init__(self, api_key: Optional[str] = None,):
        #self.base_url = "http://127.0.0.1:8000"
        self.base_url = "http://ai.ignite.team:8000"
        self.api_key = api_key
        self.headers = {"X-Ignite-Key": self.api_key}

        token_request = requests.get(
            f"{self.base_url}/token",
            timeout=10,
            headers=self.headers,
        )

        self.tokens = json.loads(token_request.text)

    def generate_content(self):
        pass

    def generate_answer(self, payload):
        request = requests.post(
            f"{self.base_url}/search",
            json=payload,
            headers=self.headers,
            timeout=10,
        )


        try:
            request.raise_for_status()

            return json.loads(request.text)

        except requests.exceptions.HTTPError as e:
            pass


    def generate_assist(self, payload):
        request = requests.post(
            f"{self.base_url}/assist",
            json=payload,
            headers=self.headers,
            timeout=10,
        )

        try:
            request.raise_for_status()

            return json.loads(request.text)

        except requests.exceptions.HTTPError as e:
            pass

    def generate_embedding(self, payload):
        request = requests.post(
            f"{self.base_url}/embedder",
            json=payload,
            timeout=10,
            headers=self.headers,
        )




        try:
            request.raise_for_status()

            embedding = json.loads(request.text)

            return embedding["embedded_text"]

        except requests.exceptions.HTTPError as e:
            return []

    def token_count(self, payload):
        request = requests.get(
            f"{self.base_url}/token_count",
            json=payload,
            timeout=10,
            headers=self.headers,
        )

        #if request.status_code != 200:

        try:
            request.raise_for_status()

            return json.loads(request.text)

        except requests.exceptions.HTTPError as e:
            pass



        # MODEL = "gemini-2.0-flash"
        # client = genai.Client(api_key=self.api_key)
        # return client.models.count_tokens(model=MODEL, contents=contents)