import json
from typing import Optional

import requests


class Client:
    def __init__(self, api_key: Optional[str] = None,):
        #self.base_url = "http://127.0.0.1:8000"
        self.base_url = "http://ai.ignite.team:8000"
        self.api_key = api_key
        self.headers = {"X-Ignite-Key": self.api_key}

    def generate_content(self):
        pass

    def generate_answer(self, payload):
        request = requests.post(
            f"{self.base_url}/search",
            json=payload,
            headers=self.headers,
            timeout=10,
        )

        return json.loads(request.text)


    def generate_assist(self, payload):
        request = requests.post(
            f"{self.base_url}/assist",
            json=payload,
            headers=self.headers,
            timeout=10,
        )

        return json.loads(request.text)

    def generate_embedding(self, payload):
        request = requests.post(
            f"{self.base_url}/embedder",
            json=payload,
            timeout=10,
            headers=self.headers,
        )

        embedding = json.loads(request.text)

        return embedding["embedded_text"]