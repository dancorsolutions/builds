import json
from typing import Optional

import requests
#todo to move later
#from google import genai
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from functools import wraps

def requires_server(fallback=None, raise_on_down=True):
    """
    - fallback: value to return if server is down (e.g., {"input_token_limit":0,...})
    - raise_on_down: if True, raise ConnectionError; if False and fallback provided, return it
    """
    def deco(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            is_up = type(self).is_up(self)  # or object.__getattribute__(self, "is_up")( )
            if not is_up:
                if fallback is not None and not raise_on_down:
                    return fallback
                raise ConnectionError(f"Server {self.base_url} is not reachable")
            return func(self, *args, **kwargs)
        return wrapper
    return deco

class Client:
    def __init__(self, api_key: Optional[str] = None,):
        #self.base_url = "http://127.0.0.1:8000"
        self.base_url = "http://ai.ignite.team:8000"
        self.api_key = api_key
        self.headers = {"X-Ignite-Key": self.api_key}

        self.session = requests.Session()
        # retries = Retry(
        #     total=3,
        #     backoff_factor=0.5,
        #     status_forcelist=[429, 500, 502, 503, 504],
        #     allowed_methods={"GET", "POST", "HEAD"},
        #     raise_on_status=False,
        # )
        # self.session.mount("http://", HTTPAdapter(max_retries=retries))
        # self.session.mount("https://", HTTPAdapter(max_retries=retries))

        self.tokens = self.tokens()


    # def __getattribute__(self, name):
    #     """Wrap all public methods so they check is_up() before running."""
    #     attr = object.__getattribute__(self, name)
    #
    #     # Only wrap callable public methods (skip dunders/private helpers/is_up itself)
    #     if callable(attr) and not name.startswith("_") and name not in {"is_up"}:
    #         def wrapper(*args, **kwargs):
    #             if not self.is_up():
    #
    #                 raise ConnectionError(f"Server {self.base_url} is not reachable")
    #             return attr(*args, **kwargs)
    #
    #         return wrapper
    #     return attr

    def is_up(self) -> bool:
        """Lightweight connectivity probe; prefer /health if available."""
        try:
            r = self.session.get(
                f"{self.base_url}/",
                headers=self.headers,
                timeout=(3, 5),  # (connect, read)
            )
            return r.status_code == 200
        except requests.RequestException as e:
            #log.warning("Health check failed for %s: %s", self.base_url, e)
            return False

    def generate_content(self):
        pass

    @requires_server(fallback=[], raise_on_down=False)
    def generate_answer(self, payload):



        try:
            request = requests.post(
                f"{self.base_url}/search",
                json=payload,
                headers=self.headers,
                timeout=10,
            )

            request.raise_for_status()

            return json.loads(request.text)

        except requests.exceptions.HTTPError as e:
            pass

    @requires_server(fallback=[], raise_on_down=False)
    def generate_assist(self, payload):


        try:

            request = requests.post(
                f"{self.base_url}/assist",
                json=payload,
                headers=self.headers,
                timeout=10,
            )

            request.raise_for_status()

            return json.loads(request.text)

        except requests.exceptions.HTTPError as e:
            pass

    @requires_server(fallback=[[]], raise_on_down=False)
    def generate_embedding(self, payload):


        try:

            request = requests.post(
                f"{self.base_url}/embedder",
                json=payload,
                timeout=10,
                headers=self.headers,
            )

            request.raise_for_status()

            embedding = json.loads(request.text)

            return embedding["embedded_text"]

        except requests.exceptions.HTTPError as e:
            return [[]]

    @requires_server(fallback=dict(total_tokens=0),raise_on_down=False)
    def token_count(self, payload):


        #if request.status_code != 200:

        try:
            request = requests.get(
                f"{self.base_url}/token_count",
                json=payload,
                timeout=10,
                headers=self.headers,
            )

            request.raise_for_status()

            return json.loads(request.text)

        #except requests.exceptions.HTTPError as e:
        except (requests.exceptions.RequestException, ConnectionError):
            pass



        # MODEL = "gemini-2.0-flash"
        # client = genai.Client(api_key=self.api_key)
        # return client.models.count_tokens(model=MODEL, contents=contents)

    @requires_server(fallback={"input_token_limit": 0, "output_token_limit": 0}, raise_on_down=False)
    def tokens(self):
        try:

            token_request = requests.get(
                f"{self.base_url}/token",
                timeout=10,
                headers=self.headers,
            )

            token_request.raise_for_status()

            self.tokens = json.loads(token_request.text)


        except (requests.exceptions.RequestException, ConnectionError):
            self.tokens = {"input_token_limit": 0, "output_token_limit": 0}

        return self.tokens