from google import genai
from google.genai import types, errors

from gemini import AI
# from ignite.tools.ai.embedder import get_embedding
# from ignite.web.common import *
# from ignite.core.config import config
# from ignite.core.utils.current import current
# from mongoengine import Q
import faiss
import numpy as np
#client = genai.Client(api_key=config.gemini.api_key)
client = genai.Client(api_key="AIzaSyBaaxpAPP_PYdMWxIsLEMLhc_b54kEfl7Q")
MODEL = "gemini-2.0-flash"

class Assist(AI):
    def __init__(self, prompt: SearchPrompt, context=None, try_again=None):
        super().__init__(self)
        self.user_prompt = prompt
        #self.user_prompt = f"{prompt}"
        self.context = prompt.context
        self.try_again = try_again

    def response(self):


        # print(self.user_prompt)
        # print(self.user_prompt.prompt)
        # return


        # ADDITIONAL_CONTEXT_RULES = [
        #     context.context_rule for context in m.IgniteAssistantContext.objects(type="assist", is_active=True)
        # ]

        self.ADDITIONAL_CONTEXT_RULES = []

        # self.ADDITIONAL_CONTEXT_RULES.append("You are an assist tool for users")
        # # self.ADDITIONAL_CONTEXT_RULES.append("Only Provide one option")
        # self.ADDITIONAL_CONTEXT_RULES.append(
        #     "Answer should be in plain text/paragraph form. Do not use markdown syntax"
        # )

        # context_rules = [
        #     "Do not generate or insert disallowed or harmful content (violence, harassment, explicit sexual content, or illegal activities).",
        #     "Follow a professional, clear, and neutral tone unless a different tone is explicitly requested by the user.",
        #     "Respect user privacy: do not generate personal, sensitive, or confidential data unless provided explicitly by the user.",
        #     "Be concise and relevant to the user's prompt, avoiding unnecessary filler text.",
        #     "Maintain factual accuracy; do not fabricate information or cite false sources.",
        #     "Do not generate medical, legal, or financial advice unless the system context explicitly allows and clarifies limitations.",
        #     "If the user requests a summary, generate a neutral, non-opinionated summary of the provided content.",
        #     "If the user requests rewriting, preserve the original meaning and key facts while improving clarity and readability.",
        #     "For tone changes, maintain the core message while adjusting sentence structure and word choice to reflect the requested tone.",
        #     "For expansions, add relevant details while staying on topic without introducing unrelated information.",
        #     "For simplification, reduce jargon and complex structures while preserving meaning.",
        #     "Do not retain or log user content beyond what is necessary for the current editing session, aligning with privacy standards.",
        #     "Avoid inserting or hallucinating URLs unless explicitly provided by the user or fetched from an allowed context.",
        #     "Respect formatting within the editor (e.g., headings, bold, links) when inserting generated content.",
        #     "If a prompt is ambiguous, return a clarifying request rather than guessing what the user wants.",
        # ]

        context_rules = [
            "You are an assist tool for users; maintain a helpful, neutral, and supportive tone.",
            "Answer should be in plain text/paragraph form without markdown syntax.",
            "Answer should not be a recommendation, but a direct answer.",
            "Do not generate or insert disallowed or harmful content (violence, harassment, explicit sexual content, or illegal activities).",
            "Respect user privacy and do not generate personal, sensitive, or confidential information unless explicitly provided by the user.",
            "Be concise, clear, and relevant to the user’s prompt, avoiding unnecessary filler text.",
            "Maintain factual accuracy and do not fabricate information or cite false sources.",
            "Do not generate medical, legal, or financial advice unless explicitly permitted in the system context, and clarify limitations if doing so.",
            # "If summarizing, produce a neutral, non-opinionated summary faithful to the provided content.",
            # "If rewriting, preserve the original meaning while improving clarity and readability.",
            # "If adjusting tone, maintain the message while reflecting the requested tone change.",
            # "If expanding, add relevant, on-topic details without introducing unrelated information.",
            # "If simplifying, reduce jargon and complexity while preserving meaning.",
            "Avoid inserting or hallucinating URLs unless explicitly provided by the user or retrieved from allowed sources.",
            # "Do not retain or log user content beyond what is necessary for the current session in alignment with privacy and data policies.",
            "If the prompt is ambiguous, respond with a clarifying question instead of guessing intent.",
        ]

        # self.ADDITIONAL_CONTEXT_RULES.extend(context_rules)
        #
        if self.context:
            self.ADDITIONAL_CONTEXT_RULES.append(self.context)
        #
        # if self.try_again and type(self.try_again) == list:
        #     self.ADDITIONAL_CONTEXT_RULES.extend(self.try_again)

        response = client.models.generate_content(
            model=MODEL,
            contents=f"{self.user_prompt.prompt}",
            config=types.GenerateContentConfig(
                #system_instruction=self.ADDITIONAL_CONTEXT_RULES,
                system_instruction=self.context,
                # response_mime_type="application/json",
            ),
        )

        result = response.text
        return result