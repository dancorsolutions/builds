import torch

from typing import List

from google import genai
from google.genai import types
from google.genai.types import EmbedContentConfig

from sentence_transformers import SentenceTransformer

from pydantic_extensions import EmbedderModel

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = SentenceTransformer("BAAI/bge-base-en-v1.5", device=device)

# Pre-warm
model.encode(["warmup text"], normalize_embeddings=True)


class Embedder:
    pass


def get_embedding(text: EmbedderModel) -> List[float]:

    embedder_text = text.text

    if type(embedder_text) == str:
        embedder_text = [text.text]


    embedding = model.encode(embedder_text, normalize_embeddings=True).tolist()

    response = EmbedderModel(
        text=text.text,
        embedded_text=embedding,
    )

    return response


# def get_embedding(text: str) -> List[float]:
#     try:
#         response = client.models.embed_content(
#             model="embedding-001",
#             contents=text,
#             config=EmbedContentConfig(
#                 task_type="RETRIEVAL_DOCUMENT",
#             ),
#         )
#
#         # response = client.models.embed_content(
#         #     model="models/embedding-001",
#         #     contents="How do I get a driver's license/learner's permit?",
#         #     config=EmbedContentConfig(
#         #         task_type="RETRIEVAL_DOCUMENT",  # Optional
#         #         output_dimensionality=3072,  # Optional
#         #         title="Driver's License",  # Optional
#         #     ),
#         # )
#
#         return response.embeddings[0].values
#     except TypeError as e:
#         print(e)
