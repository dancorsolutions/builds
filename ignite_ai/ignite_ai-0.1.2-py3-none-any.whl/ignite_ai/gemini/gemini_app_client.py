import requests


class Client:
    pass



class GeminiAppClient(Client):
    # def __init__(self, base_url: str, app_jwt: str, connect_timeout=5.0, read_timeout=60.0):
    #     self._client = httpx.Client(
    #         base_url=base_url.rstrip("/"),
    #         headers={"Authorization": f"Bearer {app_jwt}"},
    #         timeout=httpx.Timeout(connect=connect_timeout, read=read_timeout),
    #     )

    def __init__(self):
        #self.base_url = "http://127.0.0.1:8000"
        self.base_url = "http://ai.ignite.team:8000"

    def get_client(self, path):
        pass

    def search(self, payload):

        r = requests.post(f"{self.base_url}/search", json=payload, timeout=10)

        return r.json()