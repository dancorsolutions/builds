
from google import genai
# genai.configure(api_key=config.gemini.api_key)

MODEL = "gemini-2.0-flash"

def token_count(api_key, contents):
    client = genai.Client(api_key=api_key)

    return client.models.count_tokens(model=MODEL, contents=contents)