from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from rustici_api.api.about_api import AboutApi
from rustici_api.api.app_management_api import AppManagementApi
from rustici_api.api.content_connectors_api import ContentConnectorsApi
from rustici_api.api.course_api import CourseApi
from rustici_api.api.ping_api import PingApi
from rustici_api.api.player_api import PlayerApi
from rustici_api.api.registration_api import RegistrationApi
from rustici_api.api.xapi_api import XapiApi
